/**
 * Anvex approval gateway for the Pi engine.
 *
 * Every Pi tool call is routed to the host (Kotlin) through the RPC
 * extension-UI channel: the host maps the call to an Anvex BoltAction,
 * decides via CommandApprovalService (safe actions and durable grants
 * pass instantly; anything else becomes a real user prompt), and the
 * answer returns here as the confirm result. Denied or unanswerable
 * calls are blocked — fail-closed, exactly like the native harness.
 *
 * The confirm message carries a machine-readable payload so the host
 * does not have to parse prose:
 *   line 1: tool=<name>
 *   line 2: input=<full JSON, untruncated — v4.10.2: a 4000-char
 *   truncation here made every write/edit/bash over ~4 KB unparseable
 *   in PiToolMapping.parseGatewayConfirm, so large files could never
 *   be written through Pi. The 300-char compact form survives only
 *   in the human-readable prose below, never in the machine payload.>
 * A short human-readable rendering follows for the dialog.
 */
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";

function compact(value: unknown, max = 600): string {
	let s: string;
	try {
		s = typeof value === "string" ? value : JSON.stringify(value) ?? "";
	} catch {
		s = String(value);
	}
	return s.length > max ? s.slice(0, max) + "…" : s;
}

export default function (pi: ExtensionAPI) {
	pi.on("tool_call", async (event, ctx) => {
		if (!ctx.hasUI) {
			return { block: true, reason: "Anvex gateway: no approval channel available (fail-closed)." };
		}
		const inputJson = (() => { try { return JSON.stringify(event.input) ?? ""; } catch { return String(event.input); } })();
		const message =
			`tool=${event.toolName}\ninput=${inputJson}\n\n` +
			`Tool: ${event.toolName}\n${compact(event.input, 300)}`;
		const allowed = await ctx.ui.confirm("Anvex approval", message, { timeout: 600_000 });
		return allowed
			? undefined
			: { block: true, reason: "Denied by the Anvex approval gateway." };
	});
}
