/**
 * Anvex Pi engine driver — runs inside the app's :node process.
 *
 * Android cannot exec a node binary, so Pi's CLI bundle is imported into
 * THIS process: process.argv is preset for RPC mode and process.stdin /
 * process.stdout are swapped for an in-memory loopback BEFORE the import
 * (Pi's RPC mode reads commands from stdin and writes JSONL records to
 * stdout). The driver connects OUT to a localhost control socket owned
 * by the Kotlin PiEngine (the same direction preload.js uses — JS-side
 * listen sockets are not relied on anywhere in this stack). The Kotlin
 * side speaks Pi's own JSONL protocol over that socket, nearly verbatim:
 *
 *   Kotlin -> driver : first line = config JSON (consumed by the driver),
 *                      then Pi RPC commands + extension_ui_responses.
 *   driver -> Kotlin : every Pi record, relayed as-is.
 *
 * The provider API key reaches Pi ONLY inside config.modelsJson, which
 * is written verbatim to <agentDir>/models.json (the protected .anvex-pi
 * agent dir) with the key embedded literally in the provider entry. It
 * is NEVER placed in this process's environment (M-1): Pi's bash
 * children inherit that environment, so a key there is one `env` dump
 * away from the model. The raw config.apiKey field is deliberately not
 * propagated anywhere.
 *
 * Teardown is host-managed (Phase-2 finding): Pi keeps the event loop
 * alive and process.exit() does not end the embedded libnode loop, so
 * the host stops the :node process once a run settles.
 *
 * argv: [workdirAbs, runtimeDirAbs, controlPort, controlToken]
 *   workdirAbs   — project workspace (Pi's cwd; tool effects land here)
 *   runtimeDirAbs— extracted pi-runtime (pi/, ext/, vendor/)
 *   controlPort  — the Kotlin PiEngine's listening socket port
 * State: agentDir is <workdirAbs>/.anvex-pi/agent unless the config
 * overrides it (tests do); sessions persist there across runs.
 */
import net from "node:net";
import { PassThrough } from "node:stream";
import { createInterface } from "node:readline";
import { mkdirSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { pathToFileURL } from "node:url";

const [workdirArg, runtimeDirArg, controlPortArg, controlToken] = process.argv.slice(2);
const workdir = resolve(workdirArg);
const runtimeDir = resolve(runtimeDirArg);
const controlPort = Number(controlPortArg);
const realStdout = process.stdout;
const realExit = process.exit.bind(process);

let toPi = null;
let booted = false;

function fatal(msg) {
	try { realStdout.write(`ANVEX_PI_FATAL ${msg}\n`); } catch { /* noop */ }
	realExit(1);
}

if (!Number.isInteger(controlPort) || controlPort <= 0) {
	fatal(`bad control port: ${controlPortArg}`);
}
if (typeof controlToken !== "string" || controlToken.length < 32) {
	fatal("missing control token");
}

const control = net.connect(controlPort, "127.0.0.1");
control.setEncoding("utf8");
control.on("error", (err) => fatal(`control connect: ${err.message}`));
control.on("connect", () => {
	// H-01: prove we are the process the host launched before it sends config/API key.
	control.write(JSON.stringify({ type: "auth", token: controlToken }) + "\n");
	try { realStdout.write("ANVEX_PI_CONNECTED\n"); } catch { /* noop */ }
	const rl = createInterface({ input: control, crlfDelay: Infinity });
	let configSeen = false;
	rl.on("line", (line) => {
		if (!line.trim()) return;
		if (!configSeen) {
			configSeen = true;
			boot(JSON.parse(line)).catch((err) => fatal(`boot failed: ${err && err.message || err}`));
			return;
		}
		// Pi RPC command or extension_ui_response — relay verbatim.
		if (toPi) toPi.write(line + "\n");
	});
});
control.on("close", () => {
	// Host gone: end Pi's stdin (best effort) and let the host kill us.
	try { toPi?.end(); } catch { /* noop */ }
});

async function boot(config) {
	if (booted) return;
	booted = true;
	const agentDir = resolve(config.agentDir || join(workdir, ".anvex-pi", "agent"));
	mkdirSync(agentDir, { recursive: true });
	process.env.HOME = agentDir;
	process.env.PI_CODING_AGENT_DIR = agentDir;
	if (config.modelsJson) {
		writeFileSync(join(agentDir, "models.json"), JSON.stringify(config.modelsJson, null, 2));
	}
	process.chdir(workdir);

	toPi = new PassThrough();
	const fromPi = new PassThrough();
	Object.defineProperty(process, "stdin", { value: toPi, configurable: true });
	Object.defineProperty(process, "stdout", { value: fromPi, configurable: true });

	const out = createInterface({ input: fromPi, crlfDelay: Infinity });
	out.on("line", (line) => {
		if (!control.destroyed) {
			try { control.write(line + "\n"); } catch { /* host gone */ }
		}
	});

	const argv = [
		process.execPath,
		join(runtimeDir, "pi", "dist", "bundle", "cli.js"),
		"--mode", "rpc",
		"--session-dir", join(agentDir, "sessions"),
	];
	if (config.providerName) argv.push("--provider", config.providerName);
	if (config.modelId) argv.push("--model", config.modelId);
	// Thinking level from the Anvex Thinking setting (pi's native
	// low/medium/high/xhigh/max); passed on every run, including
	// session resumes, so the flag wins over a saved session level.
	if (config.thinkingLevel) argv.push("--thinking", config.thinkingLevel);
	if (config.sessionFile) argv.push("--session", config.sessionFile);
	argv.push("-e", join(runtimeDir, "ext", "gateway.ts"));
	for (const extra of config.extraExtensions ?? []) argv.push("-e", extra);
	process.argv = argv;

	await import(pathToFileURL(argv[1]).href);
}
